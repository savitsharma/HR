package com.example.demo.dto;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class DeductionDto {
	@Id

	private int Id;
	private double Deduction;
	private String Description;

	public int getId() {
		return Id;
	}

	public void setId(int Id) {
		this.Id = Id;
	}

	public double getDeduction() {
		return Deduction;
	}

	public void setDeduction(double deduction) {
		this.Deduction = deduction;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		this.Description = description;
	}

	@Override
	public String toString() {
		return "Deduction [id=" + Id + ", deduction=" + Deduction + ", description=" + Description + "]";
	}
}
