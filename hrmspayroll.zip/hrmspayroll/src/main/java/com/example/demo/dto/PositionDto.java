package com.example.demo.dto;
import java.util.List;
import javax.persistence.Id;

import com.example.demo.entities.Employee;

public class PositionDto {
	
	
	@Id
	private int departmentId;
	private String Name;
	private int positionId;
	
	private List<Employee> employee;
	
	
	public List<Employee> getEmployee() {
		return employee;
	}
	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}
	public int getPositionId() {
		return positionId;
	}
	public void setPositionId(int positionId) {
		this.positionId = positionId;
	}
	public int getDepartmentid() {
		return departmentId;
	}
	public void setDepartmentid(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	
	
	@Override
	public String toString() {
		return "PositionDto [departmentid=" + departmentId + ", name=" + Name + ", positionId=" + positionId + "]";
	}
	

}
