package com.example.demo.entities;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="Pay_Roll")
@Entity

public class PayRoll {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;
	private int RefNo;
	private int DateFrom;
	private int DateTo;
	private String Type;
	private String Status;
	private int DateCerated;

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public int getRefNo() {
		return RefNo;
	}

	public void setRefNo(int refNo) {
		RefNo = refNo;
	}

	public int getDateFrom() {
		return DateFrom;
	}

	public void setDateFrom(int dateFrom) {
		DateFrom = dateFrom;
	}

	public int getDateTo() {
		return DateTo;
	}

	public void setDateTo(int dateTo) {
		DateTo = dateTo;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public int getDateCerated() {
		return DateCerated;
	}

	public void setDateCerated(int dateCerated) {
		DateCerated = dateCerated;
	}
}

