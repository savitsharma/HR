package com.example.demo.dto;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class PayRollDto {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int Id;
	private int refNo;
	private int dateFrom;
	private int dateTo;
	private String type;
	private String status;
	private int dateCerated;

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public int getRefNo() {
		return refNo;
	}

	public void setRefNo(int refNo) {
		this.refNo = refNo;
	}

	public int getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(int dateFrom) {
		this.dateFrom = dateFrom;
	}

	public int getDateTo() {
		return dateTo;
	}

	public void setDateTo(int dateTo) {
		this.dateTo = dateTo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getDateCerated() {
		return dateCerated;
	}

	public void setDateCerated(int dateCerated) {
		this.dateCerated = dateCerated;
	}
	

	
}
