package com.example.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name=" Payroll_Item")
public class Payroll_Item {
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	
	private int id;
	private int payrollId;
	private int employeeId;
	private String present;
	private String absent;
	private String late;
	private double salary;
	private double allowanceAmount;
	private String allowncesType;
	private double deductionAmouont;
	private double deductions;
	private double grossNet;
	private String dateCreated;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPayrollId() {
		return payrollId;
	}

	public void setPayrollId(int payrollId) {
		this.payrollId = payrollId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getPresent() {
		return present;
	}

	public void setPresent(String present) {
		this.present = present;
	}

	public String getAbsent() {
		return absent;
	}

	public void setAbsent(String absent) {
		this.absent = absent;
	}

	public String getLate() {
		return late;
	}

	public void setLate(String late) {
		this.late = late;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public double getAllowanceAmount() {
		return allowanceAmount;
	}

	public void setAllowanceAmount(double allowanceAmount) {
		this.allowanceAmount = allowanceAmount;
	}

	public String getAllowncesType() {
		return allowncesType;
	}

	public void setAllowncesType(String allowncesType) {
		this.allowncesType = allowncesType;
	}

	public double getDeductionAmouont() {
		return deductionAmouont;
	}

	public void setDeductionAmouont(double deductionAmouont) {
		this.deductionAmouont = deductionAmouont;
	}

	public double getDeductions() {
		return deductions;
	}

	public void setDeductions(double deductions) {
		this.deductions = deductions;
	}

	public double getGrossNet() {
		return grossNet;
	}

	public void setGrossNet(double grossNet) {
		this.grossNet = grossNet;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}
}
