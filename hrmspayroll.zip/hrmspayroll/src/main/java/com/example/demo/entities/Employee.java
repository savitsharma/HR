 package com.example.demo.entities;

import com.sun.istack.NotNull;
import net.bytebuddy.utility.nullability.NeverNull;
import org.springframework.lang.NonNull;

import java.util.List;
import javax.persistence.*;


 @Entity
@Table(name="Employee")
public class Employee {
	 @GeneratedValue(strategy = GenerationType.AUTO)
	
	@Id
	private int Id;
	private int empId;

	private String firstName;
	private String LastName;
	private String MiddleName;
	@NeverNull
	private int depId;
	private double salary;


	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getMiddleName() {
		return MiddleName;
	}

	public void setMiddleName(String middleName) {
		MiddleName = middleName;
	}

	public int getDepId() {
		return depId;
	}

	public void setDepId(int depId) {
		this.depId = depId;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public List<Position> getPositions() {
		return positions;
	}





	public void setPositions(List<Position> positions) {
		this.positions = positions;
	}





	@ManyToMany(targetEntity = Position.class,cascade = {CascadeType.ALL})
	@JoinTable(
		name="employeeposition",
		joinColumns = 
		@JoinColumn(name="employeeId",referencedColumnName="id"),
	inverseJoinColumns = @JoinColumn(name="posId", referencedColumnName="positionId"))
	private List<Position> positions;
	
	
	
	

}
