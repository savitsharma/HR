package com.example.demo.controller;

import com.example.demo.dto.DeductionDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.PositionDto;
import com.example.demo.services.PositionService;

import java.util.List;

@RestController
@RequestMapping("/position")

public class PositionController {
	@Autowired
	PositionService positionService;
	@PostMapping("/position")
	 public ResponseEntity<PositionDto>saveDeduct(@RequestBody PositionDto positionDto){
		
		positionService.savePosition(positionDto);
		return new ResponseEntity<>(positionDto ,HttpStatus.CREATED);
	}
	
	@DeleteMapping("/position/{department_id}")
	public void deletePosition (@PathVariable("department_id")int departmentid) {
		
		positionService.deletePosition(departmentid);
		
		
	}
	@PutMapping("/position")
	public ResponseEntity<PositionDto>udateALLEntity(@RequestBody PositionDto positionDto){
		
		positionService.updateDeduction(positionDto);
		return new ResponseEntity<>(positionDto,HttpStatus.CREATED);
		
	}
	@GetMapping("/position")
	public List<PositionDto> getposition()
	{
		List<PositionDto> allPosition = positionService.getAllDeductionDto();
		return allPosition;
	}

}
	


