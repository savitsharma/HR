package com.example.demo.dto;



import javax.persistence.Id;
import javax.validation.constraints.NotNull;

public class AllowancesDto {


	@Id
	@NotNull(message="username shouldn't be null")
	private int Id;
	private String allowancesDescription;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		this.Id = Id;
	}
	public String getAllowancesDescription() {
		return allowancesDescription;
	}
	public void setAllowancesDescription(String allowancesDescription) {
		this.allowancesDescription = allowancesDescription;
	}
	@Override
	public String toString() {
		return "Allowances [id=" + Id + ", allowancesDescription=" + allowancesDescription + "]";
	}








}



