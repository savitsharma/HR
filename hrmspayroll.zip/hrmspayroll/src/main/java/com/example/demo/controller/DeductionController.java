package com.example.demo.controller;

import com.example.demo.dto.EmployeeDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.DeductionDto;
import com.example.demo.services.DeductionServices;

import java.util.List;

@RestController
@RequestMapping("/deductions")
public class DeductionController {
	@Autowired
	DeductionServices deductinServices;
 @PostMapping("/deduction")
 public ResponseEntity<DeductionDto>saveDeduction(@RequestBody DeductionDto deductionDto){
	 
	 deductinServices.saveDeduction(deductionDto);
	 return new ResponseEntity<>(deductionDto,HttpStatus.CREATED); 
 }
 @DeleteMapping("/deduction/{id}")
 public void deleteDeduction(@PathVariable("id")int id ) {
	 
	 deductinServices.deleteDeduction(id);	 
	 
 }
 @PutMapping("/deduction") 
 public ResponseEntity<DeductionDto>updateall(@RequestBody DeductionDto deductionDto){
	 
	 deductinServices.updateDeduction(deductionDto);
	 return new ResponseEntity<>(deductionDto,HttpStatus.CREATED);
 }
    @GetMapping("/deductions")
    public List<DeductionDto> getdeduction()
    {
        List<DeductionDto> allDeduction = deductinServices.getAllDeduction();
        return allDeduction ;
    }
 
 
 
}
