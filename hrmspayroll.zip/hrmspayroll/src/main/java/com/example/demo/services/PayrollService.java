package com.example.demo.services;





import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.PayRollRepository;

import com.example.demo.dto.PayRollDto;

import com.example.demo.entities.PayRoll;


@Service
public class PayrollService {
	
	
	@Autowired
	 PayRollRepository payrollRepository;
	
	
	public void savePayroll(PayRollDto payrollDto) {
		payrollRepository.save(payrollDtoToPayroll(payrollDto));
	
	}
	
	public List<PayRollDto> getAllPayroll (){
		List<PayRoll> listPayroll = this.payrollRepository.findAll();
		List<PayRollDto> payrollDtoList = listPayroll.stream().map(emp -> this.payrollToPayrollDto(emp)).collect(Collectors.toList());
		
		return payrollDtoList;
		
	}
	
		public void deletePayroll(int Id) {
		
			payrollRepository.deleteById(Id);
	}
		
		public PayRoll savePayroll(PayRoll payroll) {
			return payrollRepository.save(payroll);
		}
		
		 public PayRollDto payrollById(Integer Id)
		    {
		        PayRoll payroll = this.payrollRepository.findById(Id).get();
		        // Optional<Employee> byId = employeeReposatory.findById(employeeId);
		        return this.payrollToPayrollDto(payroll);

		    }


	
	
	
	public PayRoll payrollDtoToPayroll(PayRollDto payrollDto) {
		
		PayRoll payroll = new PayRoll();
		payroll.setId(payrollDto.getId());
		payroll.setDateFrom(payrollDto.getDateFrom());
		payroll.setDateTo(payrollDto.getDateTo());
		payroll.setDateCerated(payrollDto.getDateCerated());
		payroll.setRefNo(payrollDto.getRefNo());
		payroll.setStatus(payrollDto.getStatus());
		payroll.setType(payrollDto.getType());
		
		return payroll;
		
	}
	
	public PayRollDto payrollToPayrollDto(PayRoll payroll) {
		
		PayRollDto payrollDto = new PayRollDto();
		payroll.setId(payroll.getId());
		payroll.setDateFrom(payroll.getDateFrom());
		payroll.setDateTo(payroll.getDateTo());
		payroll.setDateCerated(payroll.getDateCerated());
		payroll.setStatus(payroll.getStatus());
		payroll.setType(payroll.getType());
		payroll.setRefNo(payroll.getRefNo());
		
		return payrollDto;
		
	}

}
