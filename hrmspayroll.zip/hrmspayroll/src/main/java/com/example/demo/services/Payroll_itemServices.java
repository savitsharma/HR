package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.PayrollItemRepository;

import com.example.demo.dto.Payroll_itemDto;
import com.example.demo.entities.Payroll_Item;
@Service

public class Payroll_itemServices {

	
@Autowired
	PayrollItemRepository payrollItemRepository;
	
	public void savePayrollitem(Payroll_itemDto payroll_Itemdto)
	{
		payrollItemRepository.save(payroll_Itemdtotopayroll_Item(payroll_Itemdto));
	}
	
	 public List<Payroll_itemDto> getAllpayrollitem(){

	        List<Payroll_Item> listpayrollitem= this.payrollItemRepository.findAll();
	        
	        List<Payroll_itemDto> payrolldto=listpayrollitem.stream().map(pay ->this.payroll_Itemtopayroll_Itemdto(pay)).collect(Collectors.toList());
	         return payrolldto;
	 }


	
	
	 public void deletePayrollitem(int empId){

	     payrollItemRepository.deleteById(empId);

	    }
	    public Payroll_itemDto updatePayrollitem(Payroll_itemDto payroll_Itemdto)
	    {
	    payrollItemRepository.save(payroll_Itemdtotopayroll_Item(payroll_Itemdto));
	    return payroll_Itemdto;

	    }


	 public Payroll_Item payroll_Itemdtotopayroll_Item(Payroll_itemDto payroll_Itemdto)
	    {
	          Payroll_Item Item =new Payroll_Item();
	          
	          Item.setId(payroll_Itemdto.getId());;
		      Item.setPayrollId(payroll_Itemdto.getPayrollId());
		      Item.setEmployeeId(payroll_Itemdto.getEmployeeId());
		      Item.setPresent(payroll_Itemdto.getPresent());
		      Item.setAbsent(payroll_Itemdto.getAbsent());
		      Item.setLate(payroll_Itemdto.getLate());
		      Item.setSalary(payroll_Itemdto.getSalary());
		      Item.setAllowanceAmount(payroll_Itemdto.getAllowanceAmount());
		      Item.setAllowncesType(payroll_Itemdto.getAllowncesType());
		      Item.setDeductionAmouont(payroll_Itemdto.getDeductionAmouont());
		      Item.setDeductions(payroll_Itemdto.getDeductions());
		      Item.setGrossNet(payroll_Itemdto.getGrossNet());
		      

	       
	        return Item;
	    }

	    public Payroll_itemDto payroll_Itemtopayroll_Itemdto(Payroll_Item payroll_Item)
	    {
	        Payroll_itemDto payrollItem= new Payroll_itemDto();

	      payrollItem.setId(payroll_Item.getId());;
	      payrollItem.setPayrollId(payroll_Item .getPayrollId());
	      payrollItem.setEmployeeId(payroll_Item.getEmployeeId());
	      payrollItem.setPresent(payroll_Item.getPresent());
	      payrollItem.setAbsent(payroll_Item.getAbsent());
	      payrollItem.setLate(payroll_Item.getLate());
	      payrollItem.setSalary(payroll_Item.getSalary());
	      payrollItem.setAllowanceAmount(payroll_Item.getAllowanceAmount());
	      payrollItem.setAllowncesType(payroll_Item.getAllowncesType());
	      payrollItem.setDeductionAmouont(payroll_Item.getDeductionAmouont());
	      payrollItem.setDeductions(payroll_Item.getDeductions());
	      payrollItem.setGrossNet(payroll_Item.getGrossNet());
	     
	        
	      return payrollItem;
	        
	    }
	

}
