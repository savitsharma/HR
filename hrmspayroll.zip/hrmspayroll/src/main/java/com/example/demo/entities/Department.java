package com.example.demo.entities;

import javax.persistence.*;

@Entity

public class Department {
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private int DepartmentId;
	private String Name;


	public int getDepartmentId() {
		return DepartmentId;
	}

	public void setDepartmentId(int departmentId) {
		DepartmentId = departmentId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
}
