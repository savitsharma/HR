package com.example.demo.controller;

import com.example.demo.dto.DeductionDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.DepartmentDto;
import com.example.demo.services.DepartmentServices;

import java.util.List;

@RestController
@RequestMapping("/department")
	public class DepartmentConroller {
		
		
		@Autowired
		DepartmentServices departmentService;
		
		
		@PostMapping("/department")
		public ResponseEntity<DepartmentDto > saveDep(@RequestBody DepartmentDto departmentdto){
			departmentService.saveDepartment(departmentdto);
			
			return new ResponseEntity<>(departmentdto,HttpStatus.CREATED);
			
		}

		    @DeleteMapping("/department/{departmentId}")
		    public void deleteAllo(@PathVariable("departmentId") int id){
		      
		    	
		    	departmentService.deleteDepartment(id);
		    }
	@GetMapping("/department")
	public List<DepartmentDto> getdepartment()
	{
		List<DepartmentDto> allDepartment = departmentService.getAllDepartment();
		return allDepartment ;
	}





	@PutMapping("/department")
		    public ResponseEntity<DepartmentDto> updateall(@RequestBody DepartmentDto departmentdto)
		    {
		       departmentService.updateDepartment(departmentdto);
		        return new ResponseEntity<>(departmentdto, HttpStatus.ACCEPTED);
		    }


}
