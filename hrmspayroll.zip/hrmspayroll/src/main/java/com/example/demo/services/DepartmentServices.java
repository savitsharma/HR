package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.DepartmentRepository;
import com.example.demo.dto.DepartmentDto;
import com.example.demo.entities.Department;
@Service
public class DepartmentServices {
	
	
	

	@Autowired
	DepartmentRepository departmentRepository;
	
	public void saveDepartment(DepartmentDto departmentdto)
	{
		departmentRepository.save(DepartmentdtotoDepartment(departmentdto));
	}
	
	 public List<DepartmentDto> getAllDepartment(){

	        List<Department> listDepartment= this.departmentRepository.findAll();

	

    List<DepartmentDto> departmentdtoList = listDepartment.stream().map(emp -> this.departmenttodepartmentdto(emp)).collect(Collectors.toList());
	return departmentdtoList;

	 }	
	
	
	
	 public void deleteDepartment(int empId){

	     departmentRepository.deleteById(empId);

	    }
	    public DepartmentDto updateDepartment(DepartmentDto departmentdto)
	    {
	    departmentRepository.save(DepartmentdtotoDepartment(departmentdto));
	    return departmentdto;

	    }


	 public Department DepartmentdtotoDepartment(DepartmentDto departmentdto)
	    {
	          Department department =new Department();

	       department.setDepartmentId(departmentdto.getDepartmentId());
	        department.setName(departmentdto.getName());
            

	       
	        return department;
	    }

	    public DepartmentDto departmenttodepartmentdto(Department department)
	    {
	        DepartmentDto departmentdto= new DepartmentDto();

	      department.setDepartmentId(department.getDepartmentId());
	      department.setName(department.getName());
	        return departmentdto;
	        
	    }

}



