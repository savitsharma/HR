package com.example.demo.entities;

import org.springframework.lang.NonNull;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;




@Entity
@Table(name="position")
public class Position {
	
	

	private int departmentId;
	private String Name;
	@Id
	private int positionId;

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		this.Name = name;
	}

	public int getPositionId() {
		return positionId;
	}

	public void setPositionId(int positionId) {
		this.positionId = positionId;
	}

	public List<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}


	//	public List<Employee> getEmployee() {
//		return employee;
//	}
//	public void setEmployee(List<Employee> employee) {
//		this.employee = employee;
//	}
//	

	@Override
	public String toString() {
		return "Position [departmentid=" + departmentId + ", name=" + Name + ", positionId=" + positionId
				+ ", employee=" + employee + "]";
	}


	@ManyToMany(targetEntity = Employee.class, mappedBy = "positions",
	                 cascade = {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH})
	private List<Employee> employee;

}
